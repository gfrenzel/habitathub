# Alexa Lambda Custom Skill

This is the Habitat Hub Lambda function that executes in response to Alexa voice interactions.
Deploy.cmd can be used in a Windows envirnoment with 7zip install to zip the neccessary files
for AWS Lambda.

## Packages Used
- alexa-sdk
- datejs

# Alexa Habitat Hub Custom Skill
        User: Alexa, ask Habitat Hub to give me the hot spot temperature?
        Alexa: The hot spot temperature is 78 degrees Fahrenheit.

        User: Alexa, ask Habitat Hub to give me the hot cool temperature?
        Alexa: The cool spot temperature is 78 degrees Fahrenheit.

        User: Alexa, ask Habitat Hub to give me the ambient temperature?
        Alexa: The ambient temperature is 78 degrees Fahrenheit.

        User: Alexa, ask Habitat Hub to give me the humidity?
        Alexa: The humidity is 50 percent.

        User: Alexa, ask Habitat Hub to give me the water level?
        Alexa: The water level is 10.

        User: Alexa, ask Habitat Hub to give me the last water clean date?
        Alexa: The last time the water was clean was February 22, 2018.

        User: Alexa, ask Habitat Hub when the last time the cage was clean?
        Alexa: The last time the water was clean was February 22, 2018.

        User: Alexa, ask Habitat Hub what the status is?
        Alexa:  The hot spot temperature is 78 degrees Fahrenheit.
                The cool spot temperature is 78 degrees Fahrenheit.
                The ambient temperature is 78 degrees Fahrenheit.
                The humidity is 50 percent.
                The waterlevel is 10.
                The last time the water was clean was February 22, 2018.
                The last time the cage was clean was February 22, 2018.
