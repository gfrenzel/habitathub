# Alexa Habitat Hub Custom Skill

This is a nodejs Alexa custom skill handler for Habitat Hub custom skill.  It supports questions like:

User: Alexa, ask Habitat Hub to give me the hot spot temperature?
Alexa: The hot spot temperature is 78 degrees fahrenheit.

User: Alexa, ask Habitat Hub to give me the hot cool temperature?
Alexa: The cool spot temperature is 78 degrees fahrenheit.

User: Alexa, ask Habitat Hub to give me the ambient temperature?
Alexa: The ambient temperature is 78 degrees fahrenheit.

User: Alexa, ask Habitat Hub to give me the humidity?
Alexa: The humidity is 50 percent.