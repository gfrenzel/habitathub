var config = {
    application: {
        appId: 'amzn1.ask.skill.673df69f-c1ce-4dbd-83a4-94c6b4ee4334',
        appSecret: 'is728n6h2dpt8vj84koo87obo7ndn51q853ili22dibg78tm0ha',
    },
    iot: {
        sensorBroker: {
            endPoint: 'a2y4w0zykqn9g5.iot.us-east-1.amazonaws.com',
            region: 'us-east-1',
            thingName: 'habhub_1234',
        }
    }
}